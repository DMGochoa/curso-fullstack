from config.database import Base
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    type_id = Column(Integer, ForeignKey(
        "transaction_types.id"), nullable=False)
    category_id = Column(Integer, ForeignKey(
        "transaction_categories.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    quantity = Column(Integer, nullable=False)

    type = relationship("TransactionType", back_populates="transaction")
    category = relationship("TransactionCategory",
                            back_populates="transaction")
    user = relationship("User", back_populates="transaction")
    account = relationship("Account", back_populates="transaction")
