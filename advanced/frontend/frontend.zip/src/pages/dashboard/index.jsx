import Navbar from '../../components/navbar';
import './dashboard.css';

const Dashboard = () => {
    return (
        <div className="page-container">
        <Navbar />
        <div className="dashboard-content">
            {/* Contenido de la vista del dashboard */}
        </div>
        </div>
    );
};

export default Dashboard;
