import Navbar from '../../components/navbar';
import './transactions.css';

const Transactions = () => {
    return (
        <div className="page-container">
        <Navbar />
        <div className="transactions-content">
            {/* Contenido de la vista de transacciones */}
        </div>
        </div>
    );
};

export default Transactions;
